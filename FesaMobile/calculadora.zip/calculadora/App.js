import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function App() {

  const [valor1, setValor1] = useState(0);
  const [valor2, setValor2] = useState(0);
  const [resultado, setResultado] = useState(0);

  function somar() 
  {
    if(valor1 === '' || valor2 === '') 
      {
        Alert.alert('Preencha os campos na tela!' );
        return;
      }
    let soma = Number.parseFloat(valor1.replace(',', '.')) +
               Number.parseFloat(valor2.replace(',', '.'));
    setResultado(soma);

  }
  function subtrair()
  {
    if(valor1 === '' || valor2 === '') 
      {
        Alert.alert('Preencha os campos na tela!' );
        return;
      }
    let subtracao = Number.parseFloat(valor1.replace(',', '.')) -
                    Number.parseFloat(valor2.replace(',', '.'));
    setResultado(subtracao);
  }
  function dividir()
  {
    if(valor1 === '' || valor2 === '') 
      {
        Alert.alert('Preencha os campos na tela!' );
        return;
      }
    if (Number.parseFloat(valor2.replace(',', '.')) === 0) {
      Alert.alert('Divisão por zero não é permitida!');
      return;
    }
    let divisao = Number.parseFloat(valor1.replace(',', '.')) /
                  Number.parseFloat(valor2.replace(',', '.'));
    setResultado(divisao);
  }
  function multiplicar()
  {
    if(valor1 === '' || valor2 === '') 
      {
        Alert.alert('Preencha os campos na tela!' );
        return;
      }
      let multiplicacao = Number.parseFloat(valor1.replace(',', '.')) *
                          Number.parseFloat(valor2.replace(',', '.'));
    setResultado(multiplicacao);
  }
  
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Calculadora</Text>


      <Text style={styles.labelCampo}>Digite o primeiro valor:</Text>
      <TextInput style={styles.caixaTexto}
      keyboardType='decimal-pad'
      onChangeText={(text)=> setValor1(text)}
      />

      <Text style={styles.labelCampo}>Digite o segundo valor:</Text>
      <TextInput style={styles.caixaTexto}
      keyboardType='decimal-pad'
      onChangeText={(text)=> setValor2(text)}
      />
      {/* Soma */}
      <TouchableOpacity style={styles.botaoSoma}
        onPress={() => somar()}
      >
      <Text style={styles.textoBotao}>Somar</Text>
      </TouchableOpacity>

      {/* Subtração */}
      <TouchableOpacity style={styles.botaoSubtracao}
        onPress={() => subtrair()}
      >
      <Text style={styles.textoBotao}>Subtrair</Text>
      </TouchableOpacity>

      {/* Divisão */}
      <TouchableOpacity style={styles.botaoDivisao}
        onPress={() => dividir()}
      >
      <Text style={styles.textoBotao}>Dividir</Text>
      </TouchableOpacity>

      {/* Multiplicação */}
      <TouchableOpacity style={styles.botaoMultiplicacao}
        onPress={() => multiplicar()}
      >
      <Text style={styles.textoBotao}>Multiplicar</Text>
      </TouchableOpacity>

      {/* Resultado */}
      <Text style={styles.labelCampo}>
        Resultado: {resultado}
      </Text>

      {/* Rodape */}
      <Text style={styles.rodape}>Desenvolvido por João Barros e Kaiki Fischer</Text>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f6fc',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  titulo: {
    fontSize: 32, 
    borderColor: '#1976d2',
    borderWidth: 2,
    padding: 20,
    marginBottom: 25,
    color: "#1976d2",
    borderRadius: 12,
    backgroundColor: '#e3f2fd',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  caixaTexto: {
    fontSize: 20,
    backgroundColor: '#e8f5e9',
    borderBottomColor: '#388e3c',
    borderBottomWidth: 2,
    width: '80%',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    marginTop: 5,
  },
  labelCampo: {
    fontSize: 20,
    color: '#d32f2f',
    marginBottom: 5,
    marginTop: 15,
    fontWeight: '600',
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
  botaoSoma: {
    width: '80%',
    backgroundColor: '#bbdefb',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    marginTop: 15,
    marginBottom: 5,
    elevation: 3,
  },
  botaoSubtracao: {
    width: '80%',
    backgroundColor: '#ffcdd2',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    marginTop: 10,
    marginBottom: 5,
    elevation: 3,
  },
  botaoDivisao: {
    width: '80%',
    backgroundColor: '#c5cae9',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    marginTop: 10,
    marginBottom: 5,
    elevation: 3,
  },
  botaoMultiplicacao: {
    width: '80%',
    backgroundColor: '#ffe0b2',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    marginTop: 10,
    marginBottom: 15,
    elevation: 3,
  },
  textoBotao: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  rodape: {
    fontSize: 16,
    color: '#1976d2',
    marginTop: 60,
    opacity: 0.7,
    textAlign: 'center',
  },
});
