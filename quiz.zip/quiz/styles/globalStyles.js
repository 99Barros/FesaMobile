import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ccc',
    alignItems: 'center',
  },
  resultado:{
    alignItems:'center'
  },
  titulo:{
    fontSize:20,
    fontWeight:'bold',
    marginBottom:20
  },
  texto:{
    fontSize:18,
    marginBottom:20
  },
  botao:{
    alignSelf:'center',
    borderColor:'#AAA',
    borderWidth:1,
    width:250,
    marginVertical:10,
    padding:15,
    borderRadius:5,
    alignItems:'center'
  },
  textoBotao:{
    fontSize:17
  },
  botaoCorreto:{
    backgroundColor:'#C8E6C9',
    borderColor: '#388e3c'
  },
  botaoIncorreto:{
    backgroundColor:'#ffcdd2',
    borderColor: '#d32f2f'
  }

});