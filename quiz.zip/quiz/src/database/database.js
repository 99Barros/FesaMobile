import * as SQLite from 'expo-sqlite';

// 1. A função mudou para openDatabaseSync
const db = SQLite.openDatabaseSync('quiz.db');

// 2. A inicialização agora usa execSync para rodar SQL puro
export const initDB = () => {
  try {
    db.execSync(`

      DROP TABLE IF EXISTS perguntas;
      DROP TABLE IF EXISTS temas;
      
      CREATE TABLE IF NOT EXISTS temas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE
      );
      CREATE TABLE IF NOT EXISTS perguntas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tema_id INTEGER NOT NULL,
        pergunta TEXT NOT NULL,
        alternativa_a TEXT NOT NULL,
        alternativa_b TEXT NOT NULL,
        alternativa_c TEXT NOT NULL,
        alternativa_d TEXT NOT NULL,
        correta TEXT NOT NULL,
        FOREIGN KEY (tema_id) REFERENCES temas (id)
      );

      INSERT OR IGNORE INTO temas (nome) VALUES ('Comida');
      INSERT OR IGNORE INTO temas (nome) VALUES ('Lugar');
      INSERT OR IGNORE INTO temas (nome) VALUES ('Carros');

      INSERT INTO perguntas (tema_id, pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta) VALUES
      (1, 'Qual o principal ingrediente da feijoada?', 'Arroz', 'Feijão', 'Carne de Porco', 'Farinha', 'B'),
      (1, 'Qual destes pratos é de origem italiana?', 'Sushi', 'Pizza', 'Tacos', 'Paella', 'B'),
      (1, 'O que é um croissant?', 'Um tipo de pão doce', 'Um tipo de bolo', 'Um tipo de massa folhada', 'Um tipo de biscoito', 'C'),
      (1, 'Qual a fruta mais consumida no mundo?', 'Maçã', 'Banana', 'Laranja', 'Morango', 'B'),
      (1, 'De qual país o chocolate é originário?', 'Suíça', 'Bélgica', 'México', 'Gana', 'C');

      INSERT INTO perguntas (tema_id, pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta) VALUES
      (2, 'Onde fica a Torre Eiffel?', 'Roma', 'Londres', 'Paris', 'Berlim', 'C'),
      (2, 'Qual a capital do Brasil?', 'Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador', 'C'),
      (2, 'Em que país ficam as pirâmides de Gizé?', 'Grécia', 'Egito', 'México', 'Peru', 'B'),
      (2, 'Qual o maior oceano do mundo?', 'Atlântico', 'Índico', 'Ártico', 'Pacífico', 'D'),
      (2, 'Onde está localizado o Cristo Redentor?', 'São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Porto Alegre', 'B');

      INSERT INTO perguntas (tema_id, pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta) VALUES
      (3, 'Qual empresa fabrica o modelo "Fusca"?', 'Ford', 'Chevrolet', 'Volkswagen', 'Fiat', 'C'),
      (3, 'Qual a marca do carro de luxo "Ferrari"?', 'Italiana', 'Alemã', 'Japonesa', 'Americana', 'A'),
      (3, 'O que significa a sigla "SUV" em carros?', 'Super Utility Vehicle', 'Sport Utility Vehicle', 'Special Urban Vehicle', 'Superior Universal Vehicle', 'B'),
      (3, 'Qual o carro mais vendido da história?', 'Volkswagen Fusca', 'Ford Modelo T', 'Toyota Corolla', 'Honda Civic', 'C'),
      (3, 'Qual empresa é conhecida por seus carros elétricos e pelo modelo "Model S"?', 'Ford', 'Tesla', 'BMW', 'Nissan', 'B');
   `);
    console.log("Tabelas criadas com sucesso!");
  } catch (error) {
    console.error("Erro ao inicializar o banco de dados:", error);
    throw error; // Propaga o erro para ser tratado onde a função for chamada
  }
};

// 3. Funções de INSERT/UPDATE/DELETE agora usam runSync
export const addTema = (nome) => {
  try {
    // runSync é para declarações que não retornam dados
    return db.runSync('INSERT INTO temas (nome) VALUES (?);', nome);
  } catch (error) {
    console.error("Erro ao adicionar tema:", error);
    throw error;
  }
};

// 4. Funções de SELECT agora usam getAllSync
export const getTemas = () => {
  try {
    // getAllSync retorna diretamente um array de objetos
    return db.getAllSync('SELECT * FROM temas;');
  } catch (error) {
    console.error("Erro ao buscar temas:", error);
    throw error;
  }
};

export const addPergunta = (pergunta) => {
  const { tema_id, pergunta: texto, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta } = pergunta;
  try {
    return db.runSync(
      'INSERT INTO perguntas (tema_id, pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta) VALUES (?, ?, ?, ?, ?, ?, ?);',
      [tema_id, texto, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta]
    );
  } catch (error) {
    console.error("Erro ao adicionar pergunta:", error);
    throw error;
  }
};

// FUNÇÃO para buscar temas com a contagem de perguntas
export const getTemasComContagem = () => {
  try {
    // LEFT JOIN para garantir que temas com 0 perguntas também apareçam
    const query = `
      SELECT 
        T.id, 
        T.nome, 
        COUNT(P.id) as quantidade 
      FROM temas T 
      LEFT JOIN perguntas P ON T.id = P.tema_id 
      GROUP BY T.id, T.nome;
    `;
    return db.getAllSync(query);
  } catch (error) {
    console.error("Erro ao buscar temas com contagem:", error);
    throw error;
  }
};

// FUNÇÃO para buscar um número específico de perguntas de um tema
export const getPerguntasPorTema = (temaId, quantidade) => {
  try {
    // ORDER BY RANDOM() pega perguntas aleatórias. LIMIT define a quantidade.
    const query = `
      SELECT * FROM perguntas 
      WHERE tema_id = ? 
      ORDER BY RANDOM() 
      LIMIT ?;
    `;
    return db.getAllSync(query, [temaId, quantidade]);
  } catch (error) {
    console.error("Erro ao buscar perguntas por tema:", error);
    throw error;
  }
};