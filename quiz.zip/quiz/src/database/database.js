// src/database/database.js

import * as SQLite from 'expo-sqlite';

// 1. A função mudou para openDatabaseSync
const db = SQLite.openDatabaseSync('quiz.db');

// 2. A inicialização agora usa execSync para rodar SQL puro
export const initDB = () => {
  try {
    db.execSync(`
      CREATE TABLE IF NOT EXISTS temas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE
      );
      CREATE TABLE IF NOT EXISTS perguntas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tema_id INTEGER NOT NULL,
        pergunta TEXT NOT NULL,
        alternativa_a TEXT NOT NULL,
        alternativa_b TEXT NOT NULL,
        alternativa_c TEXT NOT NULL,
        alternativa_d TEXT NOT NULL,
        correta TEXT NOT NULL,
        FOREIGN KEY (tema_id) REFERENCES temas (id)
      );
    `);
    console.log("Tabelas criadas com sucesso!");
  } catch (error) {
    console.error("Erro ao inicializar o banco de dados:", error);
    throw error; // Propaga o erro para ser tratado onde a função for chamada
  }
};

// 3. Funções de INSERT/UPDATE/DELETE agora usam runSync
export const addTema = (nome) => {
  try {
    // runSync é para declarações que não retornam dados
    return db.runSync('INSERT INTO temas (nome) VALUES (?);', nome);
  } catch (error) {
    console.error("Erro ao adicionar tema:", error);
    throw error;
  }
};

// 4. Funções de SELECT agora usam getAllSync
export const getTemas = () => {
  try {
    // getAllSync retorna diretamente um array de objetos
    return db.getAllSync('SELECT * FROM temas;');
  } catch (error) {
    console.error("Erro ao buscar temas:", error);
    throw error;
  }
};

export const addPergunta = (pergunta) => {
  const { tema_id, pergunta: texto, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta } = pergunta;
  try {
    return db.runSync(
      'INSERT INTO perguntas (tema_id, pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta) VALUES (?, ?, ?, ?, ?, ?, ?);',
      [tema_id, texto, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta]
    );
  } catch (error) {
    console.error("Erro ao adicionar pergunta:", error);
    throw error;
  }
};