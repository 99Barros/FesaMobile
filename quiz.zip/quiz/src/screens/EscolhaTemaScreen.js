import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useFocusEffect } from '@react-navigation/native';
import { getTemasComContagem } from '../database/database';

const EscolhaTemaScreen = ({ navigation }) => {
  const [temas, setTemas] = useState([]);
  const [selectedTemaId, setSelectedTemaId] = useState(null);
  const [quantidade, setQuantidade] = useState('');

  // useFocusEffect roda toda vez que a tela entra em foco.
  // Isso garante que a lista de temas e contagens esteja sempre atualizada.
  useFocusEffect(
    useCallback(() => {
      let isActive = true;

      const fetchTemas = () => {
        try {
          const temasDoBanco = getTemasComContagem();
          if (isActive) {
            setTemas(temasDoBanco);
            if (temasDoBanco.length > 0) {
              setSelectedTemaId(temasDoBanco[0].id); // Seleciona o primeiro por padrão
            }
          }
        } catch (error) {
          Alert.alert("Erro", "Não foi possível carregar os temas.");
        }
      };

      fetchTemas();

      return () => {
        isActive = false;
      };
    }, [])
  );

  const handleStartQuiz = () => {
    // Validação
    const numPerguntas = parseInt(quantidade, 10);
    if (!selectedTemaId) {
      Alert.alert("Atenção", "Por favor, selecione um tema para jogar.");
      return;
    }
    if (isNaN(numPerguntas) || numPerguntas <= 0) {
      Alert.alert("Atenção", "Por favor, insira uma quantidade válida de perguntas.");
      return;
    }

    const temaSelecionado = temas.find(t => t.id === selectedTemaId);

    // Validação da quantidade de perguntas
    if (numPerguntas > temaSelecionado.quantidade) {
      Alert.alert(
        "Quantidade Inválida",
        `O tema "${temaSelecionado.nome}" só possui ${temaSelecionado.quantidade} perguntas cadastradas. Por favor, escolha um número menor ou igual.`
      );
      return;
    }

    // Se tudo estiver certo, navega para a tela do Jogo
    // Passamos o ID do tema e a quantidade como parâmetros
    navigation.navigate('Game', { 
      temaId: selectedTemaId, 
      quantidade: numPerguntas 
    });
  };

  const temaAtual = temas.find(t => t.id === selectedTemaId);

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Preparar Quiz</Text>

        <Text style={styles.label}>1. Escolha um tema:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={selectedTemaId}
            onValueChange={(itemValue) => setSelectedTemaId(itemValue)}
            enabled={temas.length > 0}
          >
            {temas.length > 0 ? (
              temas.map(tema => (
                <Picker.Item 
                  key={tema.id} 
                  label={`${tema.nome} (${tema.quantidade} perguntas)`} 
                  value={tema.id} 
                />
              ))
            ) : (
              <Picker.Item label="Cadastre um tema primeiro" value={null} />
            )}
          </Picker>
        </View>

        <Text style={styles.label}>2. Digite a quantidade de perguntas:</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 5"
          keyboardType="numeric"
          value={quantidade}
          onChangeText={setQuantidade}
        />
        {temaAtual && (
            <Text style={styles.infoText}>
                Disponíveis: {temaAtual.quantidade}
            </Text>
        )}

        <TouchableOpacity 
          style={[styles.button, !temaAtual || temaAtual.quantidade === 0 ? styles.buttonDisabled : {}]} 
          onPress={handleStartQuiz}
          disabled={!temaAtual || temaAtual.quantidade === 0}
        >
          <Text style={styles.buttonText}>Iniciar Jogo</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 25,
    color: '#333',
  },
  label: {
    fontSize: 16,
    color: '#555',
    marginBottom: 10,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
  },
  infoText: {
    textAlign: 'right',
    color: '#777',
    fontStyle: 'italic',
    marginTop: -5,
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#28a745', // Um verde para "iniciar"
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonDisabled: {
    backgroundColor: '#aaa',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default EscolhaTemaScreen;