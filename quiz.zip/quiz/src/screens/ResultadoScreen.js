import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';

const ResultadoScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { resultados } = route.params;

  const totalPerguntas = resultados.length;
  const acertos = resultados.filter(r => r.acertou).length;
  const percentual = totalPerguntas > 0 ? ((acertos / totalPerguntas) * 100).toFixed(0) : 0;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.cardResumo}>
        <Text style={styles.titulo}>Resultado do Quiz!</Text>
        <Text style={styles.textoResumo}>Você acertou</Text>
        <Text style={styles.numeroAcertos}>{acertos} de {totalPerguntas}</Text>
        <Text style={styles.percentual}>{percentual}% de acerto</Text>
      </View>

      <View style={styles.detalhesContainer}>
        <Text style={styles.tituloDetalhes}>Resumo das Respostas</Text>
        {resultados.map((item, index) => (
          <View key={index} style={styles.cardPergunta}>
            <Text style={styles.textoPergunta}>{index + 1}. {item.pergunta}</Text>
            {item.acertou ? (
              <Text style={styles.feedbackCorreto}>✓ Você acertou!</Text>
            ) : (
              <View>
                <Text style={styles.feedbackIncorreto}>✗ Você errou.</Text>
                <Text style={styles.textoResposta}>Sua resposta: ({item.respostaUsuario}) {item.alternativas[item.respostaUsuario]}</Text>
                <Text style={styles.textoResposta}>Resposta correta: ({item.correta}) {item.alternativas[item.correta]}</Text>
              </View>
            )}
          </View>
        ))}
      </View>

      <TouchableOpacity 
        style={styles.botao} 
        onPress={() => navigation.popToTop()} // Volta para a tela inicial
      >
        <Text style={styles.textoBotao}>Voltar ao Início</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#f0f0f0',
      padding: 15,
    },
    cardResumo: {
      backgroundColor: 'white',
      borderRadius: 10,
      padding: 20,
      alignItems: 'center',
      marginBottom: 20,
      elevation: 5,
    },
    titulo: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 10,
    },
    textoResumo: {
      fontSize: 18,
      color: '#666',
    },
    numeroAcertos: {
      fontSize: 48,
      fontWeight: 'bold',
      color: '#007bff',
      marginVertical: 10,
    },
    percentual: {
      fontSize: 22,
      fontWeight: 'bold',
      color: '#333',
    },
    detalhesContainer: {
      marginBottom: 20,
    },
    tituloDetalhes: {
      fontSize: 20,
      fontWeight: 'bold',
      marginBottom: 10,
      textAlign: 'center',
    },
    cardPergunta: {
      backgroundColor: 'white',
      borderRadius: 8,
      padding: 15,
      marginBottom: 10,
      elevation: 2,
    },
    textoPergunta: {
      fontSize: 16,
      fontWeight: 'bold',
      color: '#333',
      marginBottom: 10,
    },
    feedbackCorreto: {
      fontSize: 16,
      color: '#28a745',
      fontWeight: 'bold',
    },
    feedbackIncorreto: {
      fontSize: 16,
      color: '#dc3545',
      fontWeight: 'bold',
    },
    textoResposta: {
      fontSize: 15,
      color: '#555',
      marginTop: 5,
    },
    botao: {
      backgroundColor: '#ff8c00',
      padding: 15,
      borderRadius: 8,
      alignItems: 'center',
      marginBottom: 20,
    },
    textoBotao: {
      color: 'white',
      fontSize: 18,
      fontWeight: 'bold',
    },
  });
  

export default ResultadoScreen;