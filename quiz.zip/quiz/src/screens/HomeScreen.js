import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, StatusBar } from 'react-native';

// O prop { navigation } é injetado automaticamente pelo React Navigation
const HomeScreen = ({ navigation }) => {

  // Função para navegar para a tela de cadastro
  const handleNavigateToCadastro = () => {
    // Usamos o nome 'Cadastro' que definiremos no nosso navegador
    navigation.navigate('Cadastro'); 
  };

  // Função para navegar para a tela de escolha de tema
  const handleNavigateToEscolhaTema = () => {
    navigation.navigate('EscolhaTema');
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <Text style={styles.title}>BEM VINDO AO QUIZ</Text>
      <Text style={styles.subtitle}>Cadastre temas e perguntas para começar a jogar!</Text>
    {/* // Botão para navegar para a tela de escolha de tema e iniciar o quiz */}
      <TouchableOpacity 
        style={[styles.button, styles.playButton]} 
        onPress={handleNavigateToEscolhaTema}
      >
        <Text style={styles.buttonText}>Jogar Quiz</Text>
      </TouchableOpacity>
      {/* Botão para navegar para a tela de cadastro */}
      <TouchableOpacity 
        style={styles.button} 
        onPress={handleNavigateToCadastro}
      >
        <Text style={styles.buttonText}>Cadastrar Temas/Perguntas</Text>
      </TouchableOpacity>
    </View>
  );
};
// Estilos para a tela inicial
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
  },
  button: {
    width: '90%',
    backgroundColor: '#ff8c00',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  playButton: {
    backgroundColor: '#007bff', // Azul para jogar
  },
  registerButton: {
    backgroundColor: '#ff8c00', // Laranja para cadastrar
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default HomeScreen;