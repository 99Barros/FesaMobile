import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, StatusBar } from 'react-native';

// O prop { navigation } é injetado automaticamente pelo React Navigation
const HomeScreen = ({ navigation }) => {

  // Função para navegar para a tela de cadastro (que criaremos no próximo passo)
  const handleNavigateToCadastro = () => {
    // Usamos o nome 'Cadastro' que definiremos no nosso navegador
    navigation.navigate('Cadastro'); 
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <Text style={styles.title}>BEM VINDO AO QUIZ</Text>
      <Text style={styles.subtitle}>Cadastre temas e perguntas para começar a jogar!</Text>

      <TouchableOpacity 
        style={styles.button} 
        onPress={handleNavigateToCadastro}
      >
        <Text style={styles.buttonText}>Cadastrar Temas/Perguntas</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
  },
  button: {
    backgroundColor: '#ff8c00',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HomeScreen;