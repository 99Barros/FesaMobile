import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { getPerguntasPorTema } from '../database/database';

const GameScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { temaId, quantidade } = route.params;

  const [perguntas, setPerguntas] = useState([]);
  const [perguntaAtualIndex, setPerguntaAtualIndex] = useState(0);
  const [respostaSelecionada, setRespostaSelecionada] = useState(null); // 'A', 'B', 'C' ou 'D'
  const [feedback, setFeedback] = useState(''); // 'correto' ou 'incorreto'
  const [respostasUsuario, setRespostasUsuario] = useState([]);

  useEffect(() => {
    // Busca as perguntas no banco de dados quando a tela carrega
    try {
      const perguntasDoBanco = getPerguntasPorTema(temaId, quantidade);
      if (perguntasDoBanco.length < quantidade) {
        Alert.alert("Erro", "Não há perguntas suficientes cadastradas para este tema.");
        navigation.goBack();
        return;
      }
      setPerguntas(perguntasDoBanco);
    } catch (error) {
      Alert.alert("Erro", "Não foi possível carregar as perguntas.");
      navigation.goBack();
    }
  }, [temaId, quantidade]);

  const handleSelecionarResposta = (alternativa) => {
    if (respostaSelecionada) return; // Impede múltiplas seleções

    setRespostaSelecionada(alternativa);
    const perguntaCorrente = perguntas[perguntaAtualIndex];
    const acertou = perguntaCorrente.correta === alternativa;

    setFeedback(acertou ? 'correto' : 'incorreto');
    
    // Salva o resultado desta pergunta
    setRespostasUsuario([
      ...respostasUsuario,
      {
        pergunta: perguntaCorrente.pergunta,
        respostaUsuario: alternativa,
        correta: perguntaCorrente.correta,
        acertou: acertou,
        alternativas: {
          A: perguntaCorrente.alternativa_a,
          B: perguntaCorrente.alternativa_b,
          C: perguntaCorrente.alternativa_c,
          D: perguntaCorrente.alternativa_d,
        }
      }
    ]);
  };

  const handleProximaPergunta = () => {
    if (!respostaSelecionada) {
        Alert.alert("Atenção", "Você precisa selecionar uma resposta.");
        return;
    }

    const proximoIndex = perguntaAtualIndex + 1;
    if (proximoIndex < perguntas.length) {
      setPerguntaAtualIndex(proximoIndex);
      setRespostaSelecionada(null); // Reseta para a próxima pergunta
      setFeedback('');
    } else {
      // Fim do quiz, navega para a tela de resultados
      navigation.replace('Resultado', 
        { resultados: respostasUsuario });
    }
  };

  if (perguntas.length === 0) {
    return <View style={styles.container}><Text>Carregando perguntas...</Text></View>;
  }

  const perguntaCorrente = perguntas[perguntaAtualIndex];
  const alternativas = [
    { key: 'A', texto: perguntaCorrente.alternativa_a },
    { key: 'B', texto: perguntaCorrente.alternativa_b },
    { key: 'C', texto: perguntaCorrente.alternativa_c },
    { key: 'D', texto: perguntaCorrente.alternativa_d },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.contador}>Pergunta {perguntaAtualIndex + 1} de {perguntas.length}</Text>
      <View style={styles.cardPergunta}>
        <Text style={styles.textoPergunta}>{perguntaCorrente.pergunta}</Text>
      </View>

      <View style={styles.alternativasContainer}>
        {alternativas.map((alt) => {
          // Lógica de estilo para feedback visual
          const isSelected = respostaSelecionada === alt.key;
          let buttonStyle = [styles.alternativa];
          if (isSelected) {
            buttonStyle.push(feedback === 'correto' ? styles.correto : styles.incorreto);
          }

          return (
            <TouchableOpacity
              key={alt.key}
              style={buttonStyle}
              onPress={() => handleSelecionarResposta(alt.key)}
              disabled={!!respostaSelecionada}
            >
              <Text style={styles.textoAlternativa}>{alt.key}: {alt.texto}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {respostaSelecionada && (
        <TouchableOpacity style={styles.botaoProxima} onPress={handleProximaPergunta}>
          <Text style={styles.textoBotaoProxima}>
            {perguntaAtualIndex === perguntas.length - 1 ? 'Ver Resultado' : 'Próxima Pergunta'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 20,
    justifyContent: 'center',
  },
  contador: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 20,
  },
  cardPergunta: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    marginBottom: 30,
    elevation: 5,
  },
  textoPergunta: {
    fontSize: 20,
    textAlign: 'center',
    color: '#333',
  },
  alternativasContainer: {
    width: '100%',
  },
  alternativa: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  textoAlternativa: {
    fontSize: 16,
  },
  correto: {
    backgroundColor: '#d4edda',
    borderColor: '#28a745',
  },
  incorreto: {
    backgroundColor: '#f8d7da',
    borderColor: '#dc3545',
  },
  botaoProxima: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  textoBotaoProxima: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default GameScreen;