import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { initDB, addTema, getTemas, addPergunta } from '../database/database';

const CadastroScreen = () => {
  const [newTema, setNewTema] = useState('');
  const [temas, setTemas] = useState([]);
  const [selectedTema, setSelectedTema] = useState(null);
  const [pergunta, setPergunta] = useState('');
  const [altA, setAltA] = useState('');
  const [altB, setAltB] = useState('');
  const [altC, setAltC] = useState('');
  const [altD, setAltD] = useState('');
  const [correta, setCorreta] = useState('A');

  // A função não precisa mais ser 'async'
  const fetchTemas = () => {
    try {
      const temasDoBanco = getTemas(); // Chamada síncrona direta
      setTemas(temasDoBanco);
      if (temasDoBanco.length > 0 && !selectedTema) {
        setSelectedTema(temasDoBanco[0].id);
      }
    } catch (error) {
      console.error("Erro ao buscar temas:", error);
      Alert.alert("Erro", "Não foi possível carregar os temas.");
    }
  };

  // useEffect agora chama as funções síncronas diretamente
  useEffect(() => {
    try {
      initDB();
      fetchTemas();
    } catch (err) {
      console.error("Erro ao inicializar DB:", err);
    }
  }, []);

  // Handler para salvar tema, agora sem 'async/await'
  const handleSaveTema = () => {
    if (!newTema.trim()) {
      Alert.alert("Atenção", "O nome do tema não pode estar vazio.");
      return;
    }
    try {
      addTema(newTema); // Chamada síncrona
      Alert.alert("Sucesso", "Tema cadastrado!");
      setNewTema('');
      fetchTemas(); // Atualiza a lista
    } catch (error) {
      Alert.alert("Erro", "Este tema já existe ou ocorreu um erro.");
    }
  };

  // Handler para salvar pergunta, agora sem 'async/await'
  const handleSavePergunta = () => {
    if (!selectedTema || !pergunta.trim() || !altA.trim() || !altB.trim() || !altC.trim() || !altD.trim()) {
      Alert.alert("Atenção", "Todos os campos da pergunta devem ser preenchidos.");
      return;
    }
    const novaPergunta = {
      tema_id: selectedTema,
      pergunta,
      alternativa_a: altA,
      alternativa_b: altB,
      alternativa_c: altC,
      alternativa_d: altD,
      correta,
    };
    try {
      addPergunta(novaPergunta); // Chamada síncrona
      Alert.alert("Sucesso", "Pergunta cadastrada!");
      setPergunta('');
      setAltA('');
      setAltB('');
      setAltC('');
      setAltD('');
      setCorreta('A');
    } catch (error) {
      Alert.alert("Erro", "Não foi possível cadastrar a pergunta.");
    }
  };


  return (
    <ScrollView style={styles.container}>
      {/* O JSX (a parte visual) permanece exatamente o mesmo */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Cadastrar Novo Tema</Text>
        <TextInput
          style={styles.input}
          placeholder="Nome do Tema"
          value={newTema}
          onChangeText={setNewTema}
        />
        <TouchableOpacity style={styles.button} onPress={handleSaveTema}>
          <Text style={styles.buttonText}>Salvar Tema</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.divider} />

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Cadastrar Nova Pergunta</Text>
        
        <Text style={styles.label}>Tema:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={selectedTema}
            onValueChange={(itemValue) => setSelectedTema(itemValue)}
          >
            {temas.map(tema => (
              <Picker.Item key={tema.id} label={tema.nome} value={tema.id} />
            ))}
          </Picker>
        </View>

        <Text style={styles.label}>Pergunta:</Text>
        <TextInput style={styles.input} placeholder="Digite a pergunta" value={pergunta} onChangeText={setPergunta} />
        
        <Text style={styles.label}>Alternativas:</Text>
        <TextInput style={styles.input} placeholder="Alternativa A" value={altA} onChangeText={setAltA} />
        <TextInput style={styles.input} placeholder="Alternativa B" value={altB} onChangeText={setAltB} />
        <TextInput style={styles.input} placeholder="Alternativa C" value={altC} onChangeText={setAltC} />
        <TextInput style={styles.input} placeholder="Alternativa D" value={altD} onChangeText={setAltD} />

        <Text style={styles.label}>Alternativa Correta:</Text>
        <View style={styles.pickerContainer}>
            <Picker
                selectedValue={correta}
                onValueChange={(itemValue) => setCorreta(itemValue)}
            >
                <Picker.Item label="Alternativa A" value="A" />
                <Picker.Item label="Alternativa B" value="B" />
                <Picker.Item label="Alternativa C" value="C" />
                <Picker.Item label="Alternativa D" value="D" />
            </Picker>
        </View>

        <TouchableOpacity style={styles.button} onPress={handleSavePergunta}>
          <Text style={styles.buttonText}>Salvar Pergunta</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  label: {
    fontSize: 16,
    color: '#555',
    marginBottom: 5,
    marginTop: 10,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 15,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
    marginBottom: 15,
  },
  button: {
    backgroundColor: '#ff8c00',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  divider: {
    height: 2,
    backgroundColor: '#e0e0e0',
    marginVertical: 10,
  }
});

export default CadastroScreen;