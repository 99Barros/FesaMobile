import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack'; 
import HomeScreen from '../screens/HomeScreen';
import CadastroScreen from '../screens/CadastroScreen'; 
import EscolhaTemaScreen from '../screens/EscolhaTemaScreen';

const Stack = createNativeStackNavigator(); 
const PlaceholderGameScreen = () => null;

const AppNavigator = () => {
  return (
    <Stack.Navigator 
      initialRouteName="Home"
      screenOptions={{
        headerStyle: { backgroundColor: '#ff8c00' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      {/* Cada stack screen representa uma tela na navegação */}

      <Stack.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{ title: 'Início do Quiz' }} 
      />
      <Stack.Screen 
        name="Cadastro" 
        component={CadastroScreen} 
        options={{ title: 'Cadastro' }} 
      />

      <Stack.Screen 
        name="EscolhaTema" 
        component={EscolhaTemaScreen} 
        options={{ title: 'Escolha o Tema' }} 
      />
      
      <Stack.Screen 
        name="Game" 
        component={PlaceholderGameScreen} 
        options={{ title: 'Quiz em Andamento' }} 
      />
    </Stack.Navigator>
  );
};

export default AppNavigator;