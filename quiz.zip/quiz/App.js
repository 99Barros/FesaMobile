import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AppNavigator from './src/navigation/AppNavigator';
import { initDB } from './src/database/database';

export default function App() {
  useEffect(() => {
    try {
      initDB();
      console.log("DB inicializado com sucesso!");
    } catch (error) {
      console.error("Falha ao inicializar o banco de dados a partir do App.js:", error);
    }
  }, []);

  return (
    <NavigationContainer>
      <AppNavigator />
    </NavigationContainer>
  );
}