export const perguntas = [ 
    {
      pergunta: 'Plataforma de hospedagem de código-fonte?',
      opcoes: ['Linkedin', 'Github', 'CodeCamp', 'Alura'],
      respostaCorreta: 1,
    },
    {
      pergunta: 'Conjunto de códigos reutilizáveis',
      opcoes: ['Javascript', 'Python', 'Biblioteca', 'Algoritmo'],
      respostaCorreta: 2,
    },
    {
      pergunta: 'Nome que se dá para erro no código:',
      opcoes: ['funcao', 'objeto', 'variável', 'bug'],
      respostaCorreta: 3,
    },  
    {
      pergunta: 'Nome que se dá para erro no código:',
      opcoes: ['funcao', 'objeto', 'variável', 'bug'],
      respostaCorreta: 3,
    },  
];

