export const temas = [
    'Naruto',
    'Programação',
    'Geografia',
];