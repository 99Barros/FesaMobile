// https://react-native-async-storage.github.io/async-storage/docs/usage
/* //npx expo install  biblioteca */    

import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import {
  Alert,
  Image,  
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import styles from "./styles";
import AsyncStorage from "@react-native-async-storage/async-storage";

import iconeContato from './assets/contato.png';

export default function App() {
  const [codigo, setCodigo] = useState("");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  function limpar() {
    setCodigo("");
    setNome("");
    setEmail("");
    setSenha("");
  }

  async function salvar() {
    let objUsuario = {
      codigo: codigo,
      nome: nome,
      email: email,
      senha: senha,
    };

    if (codigo.length == 0 || nome.length == 0 || email.length == 0 || senha == 0) {
      Alert.alert('Informe os dados.')
      return;
    }

    const stringJson = JSON.stringify(objUsuario);

    await AsyncStorage.setItem("@usuario", stringJson);
    Alert.alert("Salvo com sucesso!!!");
  }

  async function carregar() {
    const conteudoJson = await AsyncStorage.getItem("@usuario");
    console.log(conteudoJson);
    if (conteudoJson != null) {
      const objUsuario = JSON.parse(conteudoJson);
      setCodigo(objUsuario.codigo);
      setNome(objUsuario.nome);
      setEmail(objUsuario.email);
      setSenha(objUsuario.senha);
    } else {
      Alert("Não há dados cadastrados!");
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.tituloPrincipal}>Agenda de contatos</Text>


    <Image source={iconeContato}  style={styles.imagem} />

    
      <View style={styles.areaCadastro}>
        <View style={styles.areaNome}>
          <Text style={styles.legendaNome}>Código</Text>
          <TextInput
            style={styles.campoNome}
            onChangeText={setCodigo}
            value={codigo}
          />
        </View>

        <View style={styles.areaNome}>
          <Text style={styles.legendaNome}>Nome</Text>
          <TextInput
            style={styles.campoNome}
            onChangeText={setNome}
            value={nome}
          />
        </View>

        <View style={styles.areaTelefone}>
          <Text style={styles.legendaTelefone}>Email</Text>
          <TextInput
            style={styles.campoTelefone}
            onChangeText={setEmail}
            value={email}
          />
        </View>
        
        <View style={styles.areaTelefone}>
          <Text style={styles.legendaTelefone}>Senha</Text>
          <TextInput
            style={styles.campoTelefone}
            onChangeText={setSenha}
            value={senha}
            secureTextEntry={true}
          />
        </View>
      </View>

      <View style={styles.areaBotoes}>
        <TouchableOpacity style={styles.botaoSalvar} onPress={() => salvar()}>
          <Text style={styles.legendaBotao}>Salvar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botaoLimpar} onPress={() => limpar()}>
          <Text style={styles.iconeLimpar}>🧹</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botaoCarregar}
          onPress={() => carregar()}
        >
          <Text style={styles.legendaBotao}>Carregar</Text>
        </TouchableOpacity>
      </View>

      <StatusBar style="auto" />
    </View>
  );
}

